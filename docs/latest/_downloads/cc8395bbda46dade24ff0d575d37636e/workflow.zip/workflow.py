"""
Workflow example
================

Just a dummy example to illustrate the workflow examples gallery.

"""

print("Hello, World!")